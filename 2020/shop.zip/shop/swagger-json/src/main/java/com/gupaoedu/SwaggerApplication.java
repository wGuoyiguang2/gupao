package com.gupaoedu;
import com.gupaoedu.code.build.TemplateBuilder;
public class SwaggerApplication {

    public static void main(String[] args) {
        TemplateBuilder.builder();
    }
}
