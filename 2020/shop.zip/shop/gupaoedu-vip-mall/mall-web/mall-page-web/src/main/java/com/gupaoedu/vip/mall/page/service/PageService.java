package com.gupaoedu.vip.mall.page.service;

/*****
 * @Author:
 * @Description:
 ****/
public interface PageService {

    //详情页生成
    void html(String spuid) throws Exception;
}
