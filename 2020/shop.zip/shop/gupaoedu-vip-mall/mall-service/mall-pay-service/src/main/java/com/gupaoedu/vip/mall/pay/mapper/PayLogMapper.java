package com.gupaoedu.vip.mall.pay.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gupaoedu.vip.mall.pay.model.PayLog;

/*****
 * @Author:
 * @Description:
 ****/
public interface PayLogMapper extends BaseMapper<PayLog> {
}
