package com.gupaoedu.vip.mall.user.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.gupaoedu.vip.mall.user.model.UserInfo;

public interface UserInfoService extends IService<UserInfo> {
}
