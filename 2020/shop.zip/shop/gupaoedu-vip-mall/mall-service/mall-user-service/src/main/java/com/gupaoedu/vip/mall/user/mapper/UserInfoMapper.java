package com.gupaoedu.vip.mall.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gupaoedu.vip.mall.user.model.UserInfo;

public interface UserInfoMapper extends BaseMapper<UserInfo> {
}
