package com.gupaoedu.vip.mall.order.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gupaoedu.vip.mall.order.model.OrderSku;

/*****
 * @Author:
 * @Description:
 ****/
public interface OrderSkuMapper extends BaseMapper<OrderSku>{
}
