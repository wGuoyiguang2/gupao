package com.gupaoedu.vip.mall.seckill.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gupaoedu.vip.mall.seckill.model.SeckillOrder;

public interface SeckillOrderMapper extends BaseMapper<SeckillOrder> {
}
