package com.gupaoedu.vip.mall.search.service;

import com.gupaoedu.vip.mall.search.model.SeckillGoodsEs;

public interface SeckillGoodsSearchService {

    //导入到索引库
    void add(SeckillGoodsEs seckillGoodsEs);
}
