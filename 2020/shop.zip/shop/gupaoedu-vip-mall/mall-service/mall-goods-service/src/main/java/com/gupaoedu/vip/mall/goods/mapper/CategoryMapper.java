package com.gupaoedu.vip.mall.goods.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gupaoedu.vip.mall.goods.model.Category;

/*****
 * @Author: 波波
 * @Description: 云商城
 ****/
public interface CategoryMapper extends BaseMapper<Category> {
}
