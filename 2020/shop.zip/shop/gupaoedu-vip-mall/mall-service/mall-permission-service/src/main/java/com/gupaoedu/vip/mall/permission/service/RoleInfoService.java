package com.gupaoedu.vip.mall.permission.service;

import com.baomidou.mybatisplus.extension.service.IService;

import javax.management.relation.RoleInfo;

public interface RoleInfoService extends IService<RoleInfo> {
}
