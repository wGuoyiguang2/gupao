package com.gupaoedu.vip.mall.permission.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import javax.management.relation.RoleInfo;

public interface RoleInfoMapper extends BaseMapper<RoleInfo> {
}
